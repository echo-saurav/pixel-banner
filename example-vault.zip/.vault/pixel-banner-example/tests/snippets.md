---
icon: "💻"
banner: "[[code.png]]"
---
# Snippets

regex to find `console.log` statements that are not commented out:
```
(?<!\/\/\s)console\.log
```



