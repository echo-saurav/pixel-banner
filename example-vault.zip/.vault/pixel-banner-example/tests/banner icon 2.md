---
banner: "[[shooting-star.png]]"
content-start: 360
icon: v2.20.4 - ⭐ The Icon has Landed
icon-size: "30"
icon-x: "50"
icon-y: "-20"
icon-bg-color: "#00000070"
icon-padding-x: "100"
icon-padding-y: "20"
icon-font-weight: bold
---

Example `banner icon` in a note ⭐